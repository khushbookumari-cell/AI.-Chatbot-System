# AI-Chat-Bot
This repository includes Artificial Intelligence implementation in java language to create chatbot. 
Chat bot is created in Core Java and Swing Project using Notepad++ editor and Eclipse IDE. 
Projects can be run on other IDE as command line application. 
This project includes AI specific reply based on user input, basic type-error detection, text processing and text prediction.
I intend to improve this project using more use of Natural Language Processing and better Machine Learning Algorithm in future.

# Project Details

program : chat bot project created using swing and core java concepts.

# Repository Version

Github Commit Version: #1.0.0
