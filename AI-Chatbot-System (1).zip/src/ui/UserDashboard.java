package ui;

import service.ChatbotService;
import model.Feedback;
import dao.FeedbackDAO;

import java.util.Scanner;

public class UserDashboard {

    public void start(ChatbotService chatbotService) {
        Scanner sc = new Scanner(System.in);
        FeedbackDAO feedbackDAO = new FeedbackDAO();

        while (true) {
            System.out.println("\n--- User Dashboard ---");
            System.out.println("1. Ask Query");
            System.out.println("2. Submit Feedback");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");

            String line = sc.nextLine();
            int choice;
            try {
                choice = Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Try again.");
                continue;
            }

            if (choice == 1) {
                System.out.print("Enter your query: ");
                String query = sc.nextLine();
                System.out.println("Chatbot: " + chatbotService.processQuery(query));

            } else if (choice == 2) {
                System.out.print("Enter feedback message: ");
                String msg = sc.nextLine();
                Feedback fb = new Feedback(msg);
                try {
                    feedbackDAO.saveFeedback(fb);
                } catch (Exception e) {
                    System.err.println("Warning: could not save feedback to DB: " + e.getMessage());
                }
                System.out.println("Thank you for your feedback!");

            } else if (choice == 3) {
                return;
            } else {
                System.out.println("Invalid choice.");
            }
        }
    }
}
