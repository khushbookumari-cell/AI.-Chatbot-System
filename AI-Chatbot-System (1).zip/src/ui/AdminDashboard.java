package ui;

import service.AdminService;
import service.DataAnalysisService;
import service.AlgorithmService;
import service.ChatbotService;

import java.util.Scanner;

public class AdminDashboard {

    public void start(AdminService adminService,
                      DataAnalysisService analysisService,
                      AlgorithmService algoService,
                      ChatbotService chatbotService) {

        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n--- Admin Dashboard ---");
            System.out.println("1. Update Chatbot Responses");
            System.out.println("2. View Conversation Data Analysis");
            System.out.println("3. Improve AI Algorithm");
            System.out.println("4. Exit Admin Panel");
            System.out.print("Enter choice: ");

            String line = sc.nextLine();
            int choice;
            try {
                choice = Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Try again.");
                continue;
            }

            switch (choice) {
                case 1:
                    System.out.print("Enter Question: ");
                    String q = sc.nextLine();
                    System.out.print("Enter Answer: ");
                    String a = sc.nextLine();
                    adminService.updateResponse(q, a);
                    break;

                case 2:
                    analysisService.generateReport(chatbotService.getInteractionLogs());
                    break;

                case 3:
                    algoService.improveAlgorithm();
                    break;

                case 4:
                    return;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
