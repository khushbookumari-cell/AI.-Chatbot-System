package dao;

import model.InteractionLog;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LogDAO {

    public void saveLog(InteractionLog log) {
        String sql = "INSERT INTO interaction_logs(user_query, bot_response) VALUES (?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, log.getUserQuery());
            ps.setString(2, log.getBotResponse());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<InteractionLog> getAllLogs() {
        String sql = "SELECT id, user_query, bot_response, log_time FROM interaction_logs ORDER BY log_time DESC";
        List<InteractionLog> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                InteractionLog il = new InteractionLog(
                        rs.getInt("id"),
                        rs.getString("user_query"),
                        rs.getString("bot_response"),
                        rs.getTimestamp("log_time").toLocalDateTime()
                );
                list.add(il);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
