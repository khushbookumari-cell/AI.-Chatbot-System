package dao;

import model.Feedback;
import java.sql.*;

public class FeedbackDAO {

    public void saveFeedback(Feedback fb) {
        String sql = "INSERT INTO feedback(message) VALUES (?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, fb.getMessage());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
