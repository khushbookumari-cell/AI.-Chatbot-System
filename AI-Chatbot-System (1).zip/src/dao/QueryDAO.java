package dao;

import model.Query;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class QueryDAO {

    public void saveQuery(Query q) {
        String sql = "INSERT INTO queries(question, answer) VALUES (?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, q.getQuestion());
            ps.setString(2, q.getResponse());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Query> getAllQueries() {
        String sql = "SELECT id, question, answer FROM queries";
        List<Query> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Query q = new Query(rs.getInt("id"), rs.getString("question"), rs.getString("answer"));
                list.add(q);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
