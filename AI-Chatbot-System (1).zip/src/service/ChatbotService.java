package service;

import model.ChatbotConfig;
import model.InteractionLog;
import dao.LogDAO;

import java.util.ArrayList;
import java.util.List;

public class ChatbotService {

    private ChatbotConfig config;
    private List<InteractionLog> logs;
    private LogDAO logDAO;

    public ChatbotService(ChatbotConfig config) {
        this.config = config;
        this.logs = new ArrayList<>();
        this.logDAO = new LogDAO();
    }

    public String processQuery(String query) {
        String response = config.getResponse(query);
        InteractionLog log = new InteractionLog(query, response);
        logs.add(log);
        // persist to DB
        try {
            logDAO.saveLog(log);
        } catch (Exception e) {
            // log but continue
            System.err.println("Warning: could not save interaction to DB: " + e.getMessage());
        }
        return response;
    }

    public List<InteractionLog> getInteractionLogs() {
        // try to read from DB if possible
        List<InteractionLog> persisted = logDAO.getAllLogs();
        if (persisted != null && !persisted.isEmpty()) {
            return persisted;
        }
        return logs;
    }
}
