package service;

import model.ChatbotConfig;
import dao.QueryDAO;
import model.Query;

public class AdminService {

    private ChatbotConfig config;
    private QueryDAO queryDAO;

    public AdminService(ChatbotConfig config) {
        this.config = config;
        this.queryDAO = new QueryDAO();
    }

    public void updateResponse(String question, String answer) {
        config.addResponse(question, answer);
        // persist to DB
        try {
            queryDAO.saveQuery(new Query(question, answer));
        } catch (Exception e) {
            System.err.println("Warning: could not save QA to DB: " + e.getMessage());
        }
        System.out.println("Configuration updated successfully!");
    }
}
