package service;

import model.InteractionLog;
import java.util.List;

public class DataAnalysisService {

    public void generateReport(List<InteractionLog> logs) {
        System.out.println("\n----- Conversation Data Analysis Report -----");
        System.out.println("Total interactions: " + (logs == null ? 0 : logs.size()));
        if (logs != null) {
            for (InteractionLog log : logs) {
                System.out.println("Time: " + log.getLogTime());
                System.out.println("User: " + log.getUserQuery());
                System.out.println("Bot : " + log.getBotResponse());
                System.out.println("-------------------------------------------");
            }
        }
    }
}
