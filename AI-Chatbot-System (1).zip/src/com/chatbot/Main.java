package com.chatbot;

public class Main {
    public static void main(String[] args) {
        Chatbot bot = new Chatbot();
        bot.start();
    }
}
